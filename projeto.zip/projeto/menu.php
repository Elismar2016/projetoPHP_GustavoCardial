                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/fotos/<?php echo $_SESSION['foto']; ?>" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a <?= ($_SERVER['SCRIPT_NAME'] == '/painel/painel.php' ? 'class="active-menu"' : ''); ?> href="painel.php"><i class="fa fa-dashboard fa-3x"></i> Home</a>
                    </li>
					<?php
                    if ($_SESSION['nivel'] == 1) {
					?>
						<li>
                        <a <?= ($_SERVER['SCRIPT_NAME'] == '/painel/usuarios.php' ? 'class="active-menu"' : ''); ?> href="usuarios.php"><i class="fa fa-desktop fa-3x"></i> Usuários</a>
						</li>
					<?php
					}
					?>
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->