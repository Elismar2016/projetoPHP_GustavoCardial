﻿<?php require 'topo.php'; ?>
<?php require 'menu.php'; ?>

        <div id="page-wrapper" >
            <div id="page-inner">
  <h2>Usuários</h2>
  <hr>
  
  				 <?php
				 //exibição de erros
				 if (isset($_GET['erro'])) {
					 
					 if ($_GET['erro'] == 1) {
						echo '<strong><span style="color:#ff0000;">Erro:</span> e-mail já cadastrado.</strong>';
					 }
				 }
				 ?>
				 

                       <!--    Striped Rows Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Lista de Usuários
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>id</th>
                                            <th>Email</th>
                                            <th>Tipo</th>
                                            <th></th>
																			<th></th>
                                        </tr>
                                    </thead>
									<?php $conexao = new PDO('mysql:host=localhost;dbname=umbrella','root','');
                                    //select na senha do usuário informado
                                     $comando = $conexao->query('SELECT id,email,admin FROM usuarios');
									 while ($linha = $comando->fetch()){
										 $id=$linha['id'];
										 $email=htmlspecialchars($linha['email']);
										 $admin=$linha['admin'];
										 $tipo = ($admin == 0 ? 'Usuário' : 'Admin');
										 echo "<tr> <td>$id</td> <td>$email</td>   <td>$tipo</td> <td>";
										 if ($id != $_SESSION['id']) {
											 echo "<a href=\"deletarUsuario.php?id=$id\" class=\"btn btn-danger btn-xs\">deletar</a>";
										 }
										 echo "</td><td><a href=\"editarUsuario.php?id=$id\" class=\"btn btn-success btn-xs\">editar</a></td></tr>";		 							 
									 }
                                     
                                     ?>
                                    <tbody>
                                        
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--  End  Striped Rows Table  -->
                 <!-- /. ROW  --> 
				<h3>Adicionar usuário</h3>
				<form enctype="multipart/form-data" method="post" action="adicionarUsuario.php">
					<label for="email">E-mail:</label>
					<input type="email" name="email" id="email">
					
					<label for="senha">Senha:</label>
					<input type="password" name="senha" id="senha">
					
					<label for="secreta">Qual seu animal de estimação preferido</label>
									<input name="secreta" type="text" id="secreta" class="form-control" required>
									
					
					<label for="admin">Admin?</label>
					<input type="checkbox" name="admin" id="admin" value="1">
					
					<label for="foto">Foto:</label>
					<input type="file" name="foto" id="foto">
					
					<input type="submit" value="Cadastrar">
				</form>
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
