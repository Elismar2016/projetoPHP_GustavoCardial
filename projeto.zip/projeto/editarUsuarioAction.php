<?php

session_start();

if ($_SESSION['nivel'] == 0)
{
	Header('Location: http://localhost/painel/painel.php');
}

$id = $_POST['id'];
$email = $_POST['email'];
$admin = $_POST['admin'];
$senha = $_POST['senha'];

$conexao = new PDO('mysql:host=localhost;dbname=umbrella',
						'root',
						'');

						
if ($senha != '') {
	$comando = $conexao->prepare('UPDATE usuarios SET email = :e, admin = :a, senha = :s WHERE id = :i');
	$comando->bindParam(':s', $senha);
}
else {
	$comando = $conexao->prepare('UPDATE usuarios SET email = :e, admin = :a WHERE id = :i');
}

$comando->bindParam(':e', $email);
$comando->bindParam(':a', $admin);
$comando->bindParam(':i', $id);

$comando->execute();

Header('Location: http://localhost/painel/usuarios.php');

?>