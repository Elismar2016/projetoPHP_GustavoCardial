<?php
//recebe via post o email e secreta
$email = $_POST['email'];



//conectar ao banco
//selecionar usuario e senha do banco
//conferir se bate com os dados recebidos do form
$conexao = new PDO('mysql:host=localhost;dbname=umbrella','root','');
//select para confirmar se o email e a palavra secreta existe na mesma linha do banco
$comando = $conexao->prepare('SELECT id,senha,admin,foto,secreta FROM usuarios WHERE email = :e');
$comando->bindParam(':e', $email);
$comando->execute();

if ($linha = $comando->fetch()) {
	

		
		Header('Location: http://localhost/painel/confirmaResposta.php');
		exit;
}
		
	Header('Location: http://localhost/painel/login.php?erro=2');	
		

?>