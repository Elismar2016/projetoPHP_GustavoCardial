<?php require 'topo.php'; ?>
<?php require 'menu.php'; ?>
<?php

//pegar ID por GET
//consultar dados do usuário no banco, com base no ID
//gerar variáveis com os dados desse usuário

$id = $_GET['id'];

$conexao = new PDO('mysql:host=localhost;dbname=umbrella','root','');
$comando = $conexao->prepare('SELECT email,admin,foto FROM usuarios WHERE id = :i');
$comando->bindParam(':i', $id);
$comando->execute();

if ($linha = $comando->fetch()) {
	$email = $linha['email'];
	$admin = $linha['admin'];
	$foto = $linha['foto'];
}
?>

        <div id="page-wrapper" >
            <div id="page-inner">
  <h2>Usuário <?= $email ?></h2>
  <hr>				 


                 <!-- /. ROW  --> 
				<form enctype="multipart/form-data" method="post" action="editarUsuarioAction.php">
					<label for="email">E-mail:</label>
					<input type="email" name="email" id="email" value="<?= $email ?>">
					
					<label for="senha">Senha:</label>
					<input type="password" name="senha" id="senha">
					
					<label for="admin">Admin?</label>
					<input type="checkbox" name="admin" id="admin" value="1" <?= ($admin == 1 ? 'checked' : '') ?>>
					
					<input type="hidden" name="id" value="<?= $id ?>">
					
					<input type="submit" value="Atualizar">
				</form>
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
