<?php

session_start();

if ($_SESSION['nivel'] == 0)
{
	Header('Location: http://localhost/painel/painel.php');
}

$id = $_GET['id'];

if ($_SESSION['id'] == $id) {
	Header('Location: http://localhost/painel/usuarios.php');
	exit();
}

$conexao = new PDO('mysql:host=localhost;dbname=umbrella',
						'root',
						'');
//select na senha do usuário informado
$comando = $conexao->prepare("DELETE FROM usuarios WHERE id = $id");
//$comando->bindParam(':id', $id);
$comando->execute();

Header('Location: http://localhost/painel/usuarios.php');

?>