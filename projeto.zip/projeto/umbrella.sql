﻿-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 05-Jun-2017 às 02:20
-- Versão do servidor: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `umbrella`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(30) NOT NULL DEFAULT '0',
  `senha` varchar(255) NOT NULL DEFAULT '0',
  `admin` int(1) NOT NULL,
  `foto` varchar(40) NOT NULL,
  `secreta` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `senha`, `admin`, `foto`, `secreta`) VALUES
(2, 'gustavo@cardial.com.br', '$2y$10$ua17NJnJy077GW/0Cl416OWUqDhI9K9bS5Dr1a11IWB9KRUhy2y/y', 0, 'charlie.png', ''),
(8, 'gustavo.cardial@ifac.edu.br', '$2y$10$ua17NJnJy077GW/0Cl416OWUqDhI9K9bS5Dr1a11IWB9KRUhy2y/y', 1, 'vader.png', ''),
(22, 'a@h', '$2y$10$LjvrjPKyfFhRpv9tkR3IaO1F0x42P4PK.LvUaudnN6yLmyQYcSCS2', 0, '9747dc91d85820e88ed24c3d856814e4.png', 'a'),
(23, 'pedro@pedro', '$2y$10$cYHx7S9RAU.HlhCCoVJ4VumQ8SngtXAq0zw32A6edkp0BdfXStPRm', 0, '16b9e34bf5808e9c714bd877b9ff8ae9.png', 'gato');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
