<?php
//se usuário não está no formulário de login
//verificar se ele está logado
//se não estiver, redirecionar para o formulário de login

session_start();//inicia uma session para pegar o usuario logado 
       if ($_SERVER['SCRIPT_NAME'] != '/painel/login.php') {// se o script name nao for login.php
         	if ($_SERVER['SCRIPT_NAME'] != '/painel/cadastro.php') { //SEGUNDA ALTERAÇÃO DA ATIVIDADE*/
		          if ($_SERVER['SCRIPT_NAME'] != '/painel/confirmaEmail.php') { //SEGUNDA ALTERAÇÃO DA ATIVIDADE*/
		                if ($_SERVER['SCRIPT_NAME'] != '/painel/confirmaResposta.php') { //SEGUNDA ALTERAÇÃO DA ATIVIDADE*/
	                      if (!isset($_SESSION['id'])) {//e nao estiver logado com um id em session 
	   
		
		            Header('Location: http://localhost/painel/login.php'); //direciona para o login.php
		                  }
		          }
          }
      }
	   }
//se estiver no form de login
//e estiver logado
//redireciona para página inicial do painel
else {
	if (isset($_SESSION['id'])) {
		Header('Location: http://localhost/painel/painel.php');
	}
}
if ($_SERVER['SCRIPT_NAME'] == '/painel/usuarios.php') {
	if ($_SESSION['nivel'] != 1) {
		Header('Location: http://localhost/painel/painel.php');
	}
}

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login | Umbrella Corporation</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Umbrella Corp</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">
<?php
setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
date_default_timezone_set('America/Rio_branco');
echo strftime('%A, %d de %B de %Y', strtotime('today'));

//se este topo NÃO estiver aparecendo
//no formulário de login, mostrar botão de LOGOUT
if ($_SERVER['SCRIPT_NAME'] != '/painel/login.php') {
	echo '&nbsp;&nbsp;<a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a>';
}


?>
</div>
        </nav>   
           <!-- /. NAV TOP  -->