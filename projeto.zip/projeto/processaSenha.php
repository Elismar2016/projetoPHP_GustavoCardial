<?php

session_start();
$id = $_SESSION['id'];

$senha = $_POST['senha'];
$rnsenha = $_POST['rnsenha'];

if($senha != $rnsenha){
	Header('Location: http://localhost/painel/renovaSenha.php?erro=2');
	exit;
}

//conectar ao banco
//selecionar usuario e senha do banco
//conferir se bate com os dados recebidos do form
$conexao = new PDO('mysql:host=localhost;dbname=umbrella',
					'root',
					'');
					$senha = password_hash($senha, PASSWORD_DEFAULT);

//select na senha do usuário informado
$comando = $conexao->prepare('UPDATE usuarios SET senha = :s  WHERE usuarios.id = :i');
$comando->bindParam(':i', $id);
$comando->bindParam(':s', $senha);
$comando->execute();

if ($linha = $comando->fetch()) {
	
	$id = $linha['id'];
	$nivel = $linha['admin'];
	$foto = $linha['foto'];
	
	
		//abrir sessão
		session_start();
		$_SESSION['id'] = $id;
		$_SESSION['email'] = $email;
		$_SESSION['nivel'] = $nivel;
		$_SESSION['foto'] = $foto;
		Header('Location: http://localhost/painel/painel.php');
	}
	else {
		Header('Location: http://localhost/painel/login.php?erro=2');
	}







?>