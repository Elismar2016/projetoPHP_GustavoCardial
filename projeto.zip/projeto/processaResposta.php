<?php

$email = $_POST['email'];
$secreta = $_POST['secreta'];


//conectar ao banco
//selecionar usuario e senha do banco
//conferir se bate com os dados recebidos do form
$conexao = new PDO('mysql:host=localhost;dbname=umbrella',
					'root',
					'');
//select na senha do usuário informado
$comando = $conexao->prepare('SELECT id,email,senha,admin,foto,secreta FROM usuarios WHERE email = :e and secreta = :r' );
$comando->bindParam(':e', $email);
$comando->bindParam(':r', $secreta);
$comando->execute();

if ($linha = $comando->fetch()) {
		$id = $linha['id'];
	    $nivel = $linha['admin'];
		$email = $linha['email'];
	     $foto = $linha['foto'];
	
	
		//abrir sessão
		session_start();
		$_SESSION['id'] = $id;
		$_SESSION['email'] = $email;
		$_SESSION['nivel'] = $nivel;
		$_SESSION['foto'] = $foto;
		Header('Location: http://localhost/painel/renovaSenha.php');
	}
	else {
		Header('Location: http://localhost/painel/login.php?erro=2');
	}














?>