<?php
$secreta = $_POST['secreta'];
$email = $_POST['email'];
$senha= $_POST['senha'];
$foto = $_FILES['foto'];
$admin= 0;
$conexao = new PDO('mysql:host=localhost;dbname=umbrella','root','');

$comando = $conexao->prepare('SELECT id,senha FROM usuarios WHERE email = :e');
$comando->bindParam(':e', $email);
$comando->execute();

if ($linha = $comando->fetch()) {
	Header('Location: http://localhost/painel/cadastro.php?erro=1');
	exit();
}
$senha = password_hash($senha, PASSWORD_DEFAULT);
$nomeFoto = '';

/*trabalhar com o arquivo e colocá-lo na pasta de fotos*/
if (getimagesize($foto['tmp_name'])) { //verifica se é imagem
	
	$extensao = pathinfo($foto['name'])['extension'];
	$novoCaminho = 'c:\xampp\htdocs\painel\assets\fotos\\' . md5($foto['tmp_name']) . '.' . $extensao;
	$nomeFoto = md5($foto['tmp_name']) . '.' . $extensao;
	//move_uploaded_file($foto['tmp_name'], $novoCaminho);
	
	$fn = $foto['tmp_name'];
	$size = getimagesize($fn);
	$ratio = $size[0]/$size[1]; // width/height
	if( $ratio > 1) {
		$width = 128;
		$height = 128/$ratio;
	}
	else {
		$width = 128*$ratio;
		$height = 128;
	}
	$src = imagecreatefromstring(file_get_contents($fn));
	$dst = imagecreatetruecolor($width,$height);
	imagecopyresampled($dst,$src,0,0,0,0,$width,$height,$size[0],$size[1]);
	imagedestroy($src);
	imagepng($dst, $novoCaminho); // adjust format as needed
	imagedestroy($dst);

}

$comando = $conexao->prepare('INSERT INTO usuarios (email,admin,senha,foto,secreta) VALUES (:e,:a, :s,:f,:r)');
$comando->bindParam(':e', $email);
$comando->bindParam(':a', $admin);
$comando->bindParam(':s', $senha);
$comando->bindParam(':f', $nomeFoto);
$comando->bindParam(':r', $secreta);
$comando->execute();

$comando = $conexao->prepare('SELECT id,email,foto,secreta FROM usuarios WHERE email = :e');
$comando->bindParam(':e', $email);
$comando->execute();

if ($linha = $comando->fetch()) {
		   $id = $linha['id'];
		   $email = $linha ['email'];
		   $foto = $linha['foto'];
		   $nivel = $linha['nivel'];
}
session_start();
		$_SESSION['id'] = $id;
		$_SESSION['email'] = $email;
		$_SESSION['nivel'] = 0;
		$_SESSION['foto'] = $foto;



Header('Location: http://localhost/painel/painel.php');
?>