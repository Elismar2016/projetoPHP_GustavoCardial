<?php require 'topo.php'; ?>
  <!-- /. NAV SIDE  -->
  
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Renove a Senha</h2>   
                            <h5>Bem vindo <strong><?php echo $_SESSION['email']; ?></strong>, é bom vê-lo novamente.</h5>
                 </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
				  <?php
				 if (isset($_GET['erro'])) {
					 
					 if ($_GET['erro'] == 1) {
						echo '<strong><span style="color:#ff0000;">Atenção:</span> todos os campos devem ser preenchidos.</strong>';
					 }
					 
					 elseif ($_GET['erro'] == 2) {
						echo '<strong><span style="color:#ff0000;">Atenção:</span> As senhas não sao iguais.</strong>';						 
					 }
				 }
				 ?>
				    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-heading"></div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">
							
									
									  <form method="post" action="processaSenha.php">
									<label for="senha">Nova Senha</label>
								
                                   <input name="senha" id="senha" type="password"  class="form-control"  required>
					               <label for="rnsenha">Confirma Senha</label>
								
                                   <input name="rnsenha" id="rnsenha" type="password"  class="form-control"  required>
										<input type="submit" value="Cadastrar">

									</form>

                                </div>  
								</div>
                        </div>
                    </div>
                    <!-- End Form Elements -->
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
    </body>
    </html>