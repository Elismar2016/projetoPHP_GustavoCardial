<?php

$email = $_POST['email'];
$senha = $_POST['senha'];
$admin = $_POST['admin'];
$foto = $_FILES['foto'];
$secreta = $_POST['secreta'];

$conexao = new PDO('mysql:host=localhost;dbname=umbrella',
					'root',
					'');

$comando = $conexao->prepare('SELECT email FROM usuarios WHERE email = :e');
$comando->bindParam(':e', $email);
$comando->execute();

//caso o email já exista no banco
//volta pra tela de usuários informando um erro

if ($linha = $comando->fetch()) {
	Header('Location: http://localhost/painel/usuarios.php?erro=1');
	exit();
}

$admin = ($admin == 1 ? 1 : 0);
$senha = password_hash($senha, PASSWORD_DEFAULT);
$nomeFoto = '';

/*trabalhar com o arquivo e colocá-lo na pasta de fotos*/
if (getimagesize($foto['tmp_name'])) { //verifica se é imagem
	
	$extensao = pathinfo($foto['name'])['extension'];
	$novoCaminho = 'c:\xampp\htdocs\painel\assets\fotos\\' . md5($foto['tmp_name']) . '.' . $extensao;
	$nomeFoto = md5($foto['tmp_name']) . '.' . $extensao;
	//move_uploaded_file($foto['tmp_name'], $novoCaminho);
	
	$fn = $foto['tmp_name'];
	$size = getimagesize($fn);
	$ratio = $size[0]/$size[1]; // width/height
	if( $ratio > 1) {
		$width = 128;
		$height = 128/$ratio;
	}
	else {
		$width = 128*$ratio;
		$height = 128;
	}
	$src = imagecreatefromstring(file_get_contents($fn));
	$dst = imagecreatetruecolor($width,$height);
	imagecopyresampled($dst,$src,0,0,0,0,$width,$height,$size[0],$size[1]);
	imagedestroy($src);
	imagepng($dst, $novoCaminho); // adjust format as needed
	imagedestroy($dst);

}

$comando = $conexao->prepare('INSERT INTO usuarios (email, senha, admin, foto,secreta) VALUES (:e, :s, :a, :f,:r)');
$comando->bindParam(':e', $email);
$comando->bindParam(':s', $senha);
$comando->bindParam(':a', $admin);
$comando->bindParam(':f', $nomeFoto);
$comando->bindParam(':r', $secreta);
$comando->execute();

Header('Location: http://localhost/painel/usuarios.php');
exit();

?>